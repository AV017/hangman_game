class Alphabet {
  String alphabet = 'abcdefghijklmnopqrstuvwxyz';
}
